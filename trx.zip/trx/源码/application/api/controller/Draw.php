<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2021/9/2 0002
 * Time: 23:34
 */

namespace app\api\controller;


use logicmodel\DrawLogic;
use think\Request;

class Draw extends BaseController
{
    private $drawLogic;
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $this->drawLogic = new DrawLogic();
    }

    /**
     * 配置
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function config(){
        return json($this->drawLogic->config($this->userInfo,$this->admin_id));
    }
    /**
     * 申请提现
     * @param $account
     * @param $address
     * @param $pay_password
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function  draw($account,$address,$type,$pay_password){
        return json($this->drawLogic->draw($this->userInfo,$address,$type,$account,$pay_password));
    }

}