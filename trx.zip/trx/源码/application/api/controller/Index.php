<?php


namespace app\api\controller;


use logicmodel\IndexLogic;
use think\Request;

class Index extends BaseController
{
    private $indexLogic;
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $this->indexLogic = new IndexLogic();
    }



    /**
     * 系统公告列表
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function noticeList(){
        return json($this->indexLogic->noticeList($this->admin_id,$this->language_id));
    }

    /**
     * 滚动公告列表
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function newsList($type=1){
        return json($this->indexLogic->newsList($this->admin_id,$this->language_id,$type));
    }


    /**
     * 合作机构列表
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function cooperateList(){
        return json($this->indexLogic->cooperateList());
    }

    /**
     * APP下载/客服地址
     * @return \think\response\Json
     */
    public function download(){
        return json($this->indexLogic->download($this->admin_id));
    }

    /**
     * 首页假数据
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function homePage(){
        return json($this->indexLogic->homePage($this->admin_id));
    }

}