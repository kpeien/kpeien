<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2022/2/27 0027
 * Time: 15:18
 */

namespace app\api\controller;


use logicmodel\ConvertLogic;
use think\Request;

class Convert extends BaseController
{
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
    }

    /**
     * 转入基本账户
     * @param $account
     * @param $pay_password
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function convert($account,$pay_password){
        return json((new ConvertLogic())->convert($this->userInfo,$account,$pay_password));
    }
}