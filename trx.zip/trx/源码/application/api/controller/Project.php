<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2022/2/25 0025
 * Time: 23:15
 */

namespace app\api\controller;


use logicmodel\ProjectLogic;
use think\Request;

class Project extends BaseController
{
    private $projectLogic;
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $this->projectLogic = new ProjectLogic();
    }

    /**
     * 基础账户收益比例
     * @return \think\response\Json
     */
    public function projectRate(){
        return json($this->projectLogic->projectRate($this->userInfo,$this->admin_id));
    }

    /**
     * 基础账户收益记录
     * @param string $start_time
     * @param string $end_time
     * @param $page
     * @param $pagesize
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function basicRecord($start_time='',$end_time='',$page=1,$pagesize=10){
        return json($this->projectLogic->basicRecord($this->uid,$start_time,$end_time,$page,$pagesize));
    }

    /**
     * 领取收益
     * @param $id
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function receive($id){
        return json($this->projectLogic->receive($this->uid,$id));
    }

    /**
     * 投资商品列表
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function projectList(){
        return json($this->projectLogic->projectList($this->admin_id));
    }

    /**
     * 投资信息详情
     * @param $id
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function projectDetail($id){
        return json($this->projectLogic->projectDetail($this->admin_id,$id));
    }

    /**
     * 投资
     * @param $id
     * @param $account
     * @param $pay_password
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function invest($id,$account,$pay_password){
        return json($this->projectLogic->invest($this->userInfo,$id,$account,$pay_password));
    }

    /**
     * 会员投资记录
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function myProjectsRecord(){
        return json($this->projectLogic->myProjectsRecord($this->uid));
    }
}