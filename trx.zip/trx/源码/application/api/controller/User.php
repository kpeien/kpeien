<?php


namespace app\api\controller;


use logicmodel\UserLogic;
use think\Request;

class User extends BaseController
{
    private $userLogic;
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $this->userLogic = new UserLogic();
    }

    /**
     * 个人信息
     * @return \think\response\Json
     */
    public function userInfo(){
        return json($this->userLogic->userInfo($this->userInfo));
    }


    /**
     * 邀请分享
     * @return \think\response\Json
     * @throws \think\Exception
     */
    public function share(){
        return json($this->userLogic->share($this->userInfo));
    }

    /**
     * 修改登录密码
     * @param $old_password
     * @param $password
     * @param $password_re
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function updatePassword($old_password,$password,$password_re){
        return json($this->userLogic->updatePassword($this->userInfo,$old_password,$password,$password_re));
    }

    /**
     * 修改登录密码
     * @param $old_password
     * @param $pay_password
     * @param $pay_password_re
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function updatePayPassword($old_password,$pay_password,$pay_password_re){
        return json($this->userLogic->updatePayPassword($this->userInfo,$old_password,$pay_password,$pay_password_re));
    }

    /**
     * 钱包地址
     * @param int $type
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function wallet($type=1){
        return json($this->userLogic->wallet($this->userInfo,$type));
    }

}