<?php


namespace app\api\controller;


use app\lib\exception\LoginException;
use comservice\GetRedis;
use datamodel\Users;
use think\Controller;
use think\Request;

class BaseController extends Controller
{
    protected $uid;
    protected $userInfo;
    protected $language_id;
    protected $admin_id;
    public function __construct(Request $request = null)
    {
        $this->checkLogin();
        parent::__construct($request);
    }

    public function checkLogin(){
        $token =  Request::instance()->header('token');
        if (empty($token) || $token==''){
           throw  new LoginException('请先登录');
        }else {
            $redis = GetRedis::getRedis();
            $uid = $redis->getItem('app_'.$token);
            if (empty($uid) || $uid == false || !$uid){
                throw  new LoginException('请先登录');
            }
        }
        $userInfo = (new Users())
            ->where(['is_del'=>0,'id'=>$uid])
            ->find();
        if(empty($userInfo))   throw  new LoginException('用户身份信息错误');
        if($userInfo['status'] == 0)   throw  new LoginException('账户已冻结');
        if($userInfo['app_token'] != $token)  throw  new LoginException('当前账号已在其他设备登录');
        $language_id =  Request::instance()->header('language');
        $this->uid = $uid;
        $this->language_id = $language_id ? $language_id:1;
        $this->admin_id = $userInfo['admin_id'];
        $this->userInfo = $userInfo->toArray();
    }
}