<?php


namespace app\api\controller;


use logicmodel\ConfigLogic;
use logicmodel\UserLogic;
use think\captcha\Captcha;
use think\Controller;
use think\Request;
use validate\RegisterValidate;

class Login extends Controller
{
    private $userLogic;
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $this->userLogic = new UserLogic();
    }

    /**
     * 登录
     * @param $member
     * @param $password
     * @param $code
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function login($member,$password,$code){
        return json($this->userLogic->login($member,$password,$code));
    }

    /**
     * 会员注册
     * @param $uuid
     * @param $member
     * @param $password
     * @param $pay_password
     * @param $code
     * @return \think\response\Json
     * @throws \app\lib\exception\ParamException
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function register($uuid='',$member='',$password='',$pay_password='',$code=''){
        (new RegisterValidate())->goCheck();
        return json($this->userLogic->register($uuid,$member,$password,$pay_password,$code));
    }



    /**
     * 系统配置
     * @return \think\response\Json
     */
    public function config(){
        return json((new ConfigLogic())->config());
    }

    /**
     * 验证码
     * @return \think\Response
     */
    public function code(){
        ob_clean();
        $config = [
            //验证码字符
            'codeSet' => '0123456789',
            // 验证码字体大小
            'fontSize' => 50,
            // 验证码位数
            'length' => 4,
            //关闭干扰曲线
            'useCurve' => false,
            //开启验证码杂点
            'useNoise' => true,
            //开启验证码背景图
            'useImgBg' => false,
        ];
        $captcha = new Captcha($config);
        return $captcha->entry();
    }
}