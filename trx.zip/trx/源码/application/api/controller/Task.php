<?php


namespace app\api\controller;



use logicmodel\TaskLogic;
use logicmodel\WalletLogic;

class Task
{

    private $taskLogic;
    private $walletLogic;
    public function __construct()
    {
        $this->taskLogic = new TaskLogic();
        $this->walletLogic = new WalletLogic();
    }


    /**
     * 普通账户TRX入金
     * @return \think\response\Json
     * @throws \GuzzleHttp\Exception\GuzzleException
     * @throws \IEXBase\TronAPI\Exception\TronException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function trxRemittance(){
        return json($this->walletLogic->trxRemittance());
    }

    /**
     * 投资账户TRX入金
     * @return \think\response\Json
     * @throws \GuzzleHttp\Exception\GuzzleException
     * @throws \IEXBase\TronAPI\Exception\TronException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function investTrxRemittance(){
        return json($this->walletLogic->investTrxRemittance());
    }

    /**
     * 更新钱包余额
     * @return \think\response\Json
     * @throws \IEXBase\TronAPI\Exception\TronException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function updateBalance(){
        return json($this->walletLogic->updateBalance());
    }

    /**
     * 更新钱包
     * @return \think\response\Json
     * @throws \GuzzleHttp\Exception\GuzzleException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function integralRecord(){
        return json($this->walletLogic->integralRecord());
    }

    /**
     * 基础奖励每日收益
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function basicAward(){
        return json((new TaskLogic())->basicAward());
    }

    /**
     * 投资账户奖励
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function investAward(){
        return json((new TaskLogic())->investAward());
    }

    /**
     * 财务统计
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function finance(){
        return json((new TaskLogic())->finance());
    }

    /**
     * 代理商积分充值归集
     * @return \think\response\Json
     * @throws \IEXBase\TronAPI\Exception\TronException
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function integralPooling(){
        return json((new WalletLogic())->integralPooling());
    }

    /**
     * 会员充值记录归集
     * @return \think\response\Json
     * @throws \IEXBase\TronAPI\Exception\TronException
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function pooling(){
        return json((new WalletLogic())->pooling());
    }
}