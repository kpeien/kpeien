<?php


//配置文件
return [
    'exception_handle'        => '\app\lib\exception\HttpException',
];
