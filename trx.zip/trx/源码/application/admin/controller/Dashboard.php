<?php

namespace app\admin\controller;


use app\common\controller\Backend;
use datamodel\DrawRecord;
use think\Db;

/**
 * 控制台
 *
 * @icon   fa fa-dashboard
 * @remark 用于展示当前系统中的统计数据、统计报表及重要实时数据
 */
class Dashboard extends Backend
{

    /**
     * 查看
     */
    public function index()
    {
        $admin_id = $this->auth->id ;
        $time = date('Y-m-d 00:00:00');
        $yesterday_time = date('Y-m-d 00:00:00',strtotime('-1 days'));
        $remittanceRecordData = new \datamodel\RemittanceRecord();
        $drawRecordData = new DrawRecord();
        if($admin_id > 1){
            $users['is_del'] = 0;
            $users['admin_id'] = $admin_id;
            $user_count = Db::name('users')->where($users)->count();
            $user_today_count = Db::name('users')->where($users)->where(['create_time'=>['>=',$time]])->count();
            $user_yesterday_count = Db::name('users')->where($users)->where(['create_time'=>['between',[$yesterday_time,$time]]])->count();

            $remittance_today_account = $remittanceRecordData->where(['status'=>1,'create_time'=>['>=',$time],'admin_id'=>$admin_id])->sum('account');
            $remittance_today_count = $remittanceRecordData->where(['status'=>1,'create_time'=>['>=',$time],'admin_id'=>$admin_id])->count();
            $remittance_today_person = count($remittanceRecordData->where(['status'=>1,'create_time'=>['>=',$time],'admin_id'=>$admin_id])->column('uid'));

            $draw_today_account = $drawRecordData->where(['status'=>['in',[0,1]],'create_time'=>['>=',$time],'admin_id'=>$admin_id])->sum('account');
            $draw_today_count = $drawRecordData->where(['status'=>['in',[0,1]],'create_time'=>['>=',$time],'admin_id'=>$admin_id])->count();
            $draw_today_person = count($drawRecordData->where(['status'=>['in',[0,1]],'create_time'=>['>=',$time],'admin_id'=>$admin_id])->column('uid'));

            $remittance_yesterday_account = $remittanceRecordData->where(['status'=>1,'create_time'=>['between',[$yesterday_time,$time]],'admin_id'=>$admin_id])->sum('account');
            $remittance_yesterday_count = $remittanceRecordData->where(['status'=>1,'create_time'=>['between',[$yesterday_time,$time]],'admin_id'=>$admin_id])->count();
            $remittance_yesterday_person = count($remittanceRecordData->where(['status'=>1,'create_time'=>['between',[$yesterday_time,$time]],'admin_id'=>$admin_id])->column('uid'));


            $draw_yesterday_account = $drawRecordData->where(['status'=>['in',[0,1]],'create_time'=>['between',[$yesterday_time,$time]],'admin_id'=>$admin_id])->sum('account');
            $draw_yesterday_count = $drawRecordData->where(['status'=>['in',[0,1]],'create_time'=>['between',[$yesterday_time,$time]],'admin_id'=>$admin_id])->count();
            $draw_yesterday_person = count($drawRecordData->where(['status'=>['in',[0,1]],'create_time'=>['between',[$yesterday_time,$time]],'admin_id'=>$admin_id])->column('uid'));

            //今日之前充值过
            $usersArr = $remittanceRecordData->where(['status'=>1,'create_time'=>['<',$time],'admin_id'=>$admin_id])->column('uid');
           $today_first_count =  count($remittanceRecordData->where(['status'=>1,'create_time'=>['>=',$time],'admin_id'=>$admin_id])->where(['uid'=>['not in',$usersArr]])->column('uid'));

            $today_first_account =   $remittanceRecordData->where(['status'=>1,'create_time'=>['>=',$time],'admin_id'=>$admin_id])->where(['uid'=>['not in',$usersArr]])->sum('account');

            //昨日之前充值过
            $usersArr = $remittanceRecordData->where(['status'=>1,'create_time'=>['<',$yesterday_time],'admin_id'=>$admin_id])->column('uid');
            $yesterday_first_account =  $remittanceRecordData->where(['status'=>1,'create_time'=>['between',[$yesterday_time,$time]],'admin_id'=>$admin_id])->where(['uid'=>['not in',$usersArr]])->sum('account');


        }else{
            $users['is_del'] = 0;

            $user_count = Db::name('users')->where($users)->count();
            $user_today_count = Db::name('users')->where($users)->where(['create_time'=>['>=',$time]])->count();
            $user_yesterday_count = Db::name('users')->where($users)->where(['create_time'=>['between',[$yesterday_time,$time]]])->count();

            $remittance_today_account = $remittanceRecordData->where(['status'=>1,'create_time'=>['>=',$time]])->sum('account');
            $remittance_today_count = $remittanceRecordData->where(['status'=>1,'create_time'=>['>=',$time]])->count();
            $remittance_today_person = count($remittanceRecordData->where(['status'=>1,'create_time'=>['>=',$time]])->column('uid'));

            $draw_today_account = $drawRecordData->where(['status'=>['in','0,1'],'create_time'=>['>=',$time]])->sum('account');
            $draw_today_count = $drawRecordData->where(['status'=>['in','0,1'],'create_time'=>['>=',$time]])->count();
            $draw_today_person = count($drawRecordData->where(['status'=>['in','0,1'],'create_time'=>['>=',$time]])->column('uid'));

            $remittance_yesterday_account = $remittanceRecordData->where(['status'=>1,'create_time'=>['between',[$yesterday_time,$time]]])->sum('account');
            $remittance_yesterday_count = $remittanceRecordData->where(['status'=>1,'create_time'=>['between',[$yesterday_time,$time]]])->count();
            $remittance_yesterday_person = count($remittanceRecordData->where(['status'=>1,'create_time'=>['between',[$yesterday_time,$time]]])->column('uid'));

            $draw_yesterday_account = $drawRecordData->where(['status'=>['in',[0,1]],'create_time'=>['between',[$yesterday_time,$time]]])->sum('account');
            $draw_yesterday_count = $drawRecordData->where(['status'=>['in',[0,1]],'create_time'=>['between',[$yesterday_time,$time]]])->count();
            $draw_yesterday_person = count($drawRecordData->where(['status'=>['in',[0,1]],'create_time'=>['between',[$yesterday_time,$time]]])->column('uid'));

            //今日之前充值过
            $usersArr = $remittanceRecordData->where(['status'=>1,'create_time'=>['<',$time]])->column('uid');
            $today_first_count =  count($remittanceRecordData->where(['status'=>1,'create_time'=>['>=',$time]])->where(['uid'=>['not in',$usersArr]])->column('uid'));
            $today_first_account = $remittanceRecordData->where(['status'=>1,'create_time'=>['>=',$time]])->where(['uid'=>['not in',$usersArr]])->sum('account');

            //昨日之前充值过
            $usersArr = $remittanceRecordData->where(['status'=>1,'create_time'=>['<',$yesterday_time]])->column('uid');
            $yesterday_first_account =  $remittanceRecordData->where(['status'=>1,'create_time'=>['between',[$yesterday_time,$time]]])->where(['uid'=>['not in',$usersArr]])->sum('account');

        }

        $this->view->assign([
            'user_count'       => $user_count,
            'user_today_count'      => $user_today_count,
            'user_yesterday_count'      => $user_yesterday_count,

            'remittance_today_account'   => $remittance_today_account,
            'remittance_today_count'       => $remittance_today_count,
            'remittance_today_person'      => $remittance_today_person,

            'draw_today_account'      => $draw_today_account,
            'draw_today_count'=>$draw_today_count,
            'draw_today_person'   => $draw_today_person,

            'remittance_yesterday_account'       => $remittance_yesterday_account,
            'remittance_yesterday_count'      => $remittance_yesterday_count,
            'remittance_yesterday_person'      => $remittance_yesterday_person,

            'draw_yesterday_account'   => $draw_yesterday_account,
            'draw_yesterday_count'=>$draw_yesterday_count,
            'draw_yesterday_person' =>$draw_yesterday_person,

            'today_first_count'=>$today_first_count,
            'today_first_account'=>$today_first_account,
            'yesterday_first_account'=>$yesterday_first_account,

        ]);
        return $this->view->fetch();
    }

}
