<?php

namespace app\admin\controller;

use app\admin\model\config\Register;
use app\common\controller\Backend;
use logicmodel\AccountLogic;
use logicmodel\MemberLogic;
use think\Db;

/**
 * 
 *
 * @icon fa fa-users
 */
class Users extends Backend
{

    /**
     * Users模型对象
     * @var \app\admin\model\Users
     */
    protected $model = null;
    protected $dataLimit = 'auth';
    protected $dataLimitField = 'admin_id';
    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\Users;
        $this->view->assign("statusList", $this->model->getStatusList());
        $this->view->assign("isActiveList", $this->model->getIsActiveList());
        $this->view->assign("isDrawList", $this->model->getIsDrawList());
    }



    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */


    /**
     * 查看
     */
    public function index()
    {
        //当前是否为关联查询
        $this->relationSearch = true;
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();

            $list = $this->model
                    ->with(['admin'])
                    ->where(['users.is_del'=>0])
                    ->where($where)
                    ->order($sort, $order)
                    ->paginate($limit);

            foreach ($list as $row) {
                $row->visible(['id','member','status','is_active','uuid','account','basic_account','invest_account','level1_count','level2_count','level3_count','group_count','parent_member','login_time','is_draw','draw_money','draw_number','group_draw_money','remittance_money','group_remittance_money','remittance_number','invest_address','invest_address_key','basic_address','basic_address_key','create_time','recommend_award_money']);
                $row->visible(['admin']);
				$row->getRelation('admin')->visible(['username']);
            }

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }

    public function add()
    {
        if(request()->isPost()){
            $data = input('post.');
            $data = $data['row'];
            if(!empty($data['parent_member'])){
                $parentInfo = $this->model->where(['is_del'=>0,'member'=>$data['parent_member']])->find();
                if(empty($parentInfo))  $this->error('推荐人账号错误');
                $two_pid = $parentInfo['pid'];
            }else{
                $parentInfo = $this->model->where(['id'=>1])->find();
                 if(empty($parentInfo))  $this->error('推荐人账号错误');
                $two_pid = 0;
            }
                
            $member = $data['member'];
            $info = $this->model->where(['member'=>$member,'is_del'=>0])->find();
            if($info) $this->error('账号已注册');
            $password = $data['password'];
            if(empty($password) ) $this->error('请输入登录密码');
            $pay_password = $data['pay_password'];
            if(empty($pay_password) ) $this->error('请输入支付密码');
            $salt = rand(1111,9999);
            $uuid = uuid();
            $pid = $parentInfo['id'];
            $userData['admin_id'] = $this->auth->id;
            $userData['member'] = $member;
            $userData['salt'] = $salt;
            $userData['pay_salt'] = $salt;
            $userData['password'] = md5(md5($password).$salt);
            $userData['pay_password'] = md5(md5($pay_password).$salt);
            $userData['uuid'] = $uuid;
            $userData['pid'] = $pid;
            $userData['upid'] = $pid;
            $userData['parent_member'] = $parentInfo['member'];
            $userData['create_time'] = date('Y-m-d H:i:s');
            Db::startTrans();
            $user_id = $this->model->insertGetId($userData);
            if($user_id > 0) {
                $result =  $this->updateGroup($pid,$two_pid);
                if(!$result){
                    Db::rollback();
                    $this->error('注册失败');
                }
                Db::commit();
                $this->award($user_id,$this->auth->id);
                $this->success('注册成功');

            }
            Db::rollback();
            $this->error('注册失败');
        }
        return $this->fetch();
    }
    /**
     * 更新团队信息
     * @param $pid
     * @param $two_pid
     * @return bool
     * @throws \think\Exception
     */
    private function updateGroup($pid,$two_pid)
    {

        $field = ['id', 'pid', 'upid'];
        $userData = (new MemberLogic())->listParent($pid, $field, 1, 0);
        $groupArr = array_column($userData, 'id');
        $where['id']  = ['in', $groupArr];
        $result = $this->model->where($where)->setInc('group_count',1); //修改团队成员
        $res = $this->model->where(['id' => $pid])->setInc('level1_count', 1);//修改直推人数
        if($two_pid > 0){
            $this->model->where(['id' => $two_pid])->setInc('level2_count', 1);//修改二代直推人数
           $three_pid =  $this->model->where(['id'=>$two_pid])->value('pid');
           if($three_pid > 0){
               $this->model->where(['id' => $three_pid])->setInc('level3_count', 1);//修改三代直推人数
           }
        }
        if ($result > 0 && $res > 0) return true;
        return false;
    }

    public function del($ids = "")
    {
        $result = $this->model->where(['id'=>['in',$ids]])->update(['is_del'=>1]);
        if($result) return json(['code'=>1,'msg'=>'删除成功']);
        return json(['code'=>0,'msg'=>'删除失败']);
    }

    public function edit($ids = null)
    {
        if(request()->isPost()){
            $data = input('post.');
            $data = $data['row'];
            if(!empty($data['password'])){
                $salt = rand(1111,9999);
                $password = md5(md5($data['password']).$salt);
                $data['password'] = $password;
                $data['salt'] = $salt;
            }else{
                unset($data['password']);
            }
            if(!empty($data['pay_password'])){
                $salt = rand(1111,9999);
                $password = md5(md5($data['pay_password']).$salt);
                $data['pay_password'] = $password;
                $data['pay_salt'] = $salt;
            }else{
                unset($data['pay_password']);
            }
            $result = $this->model->where(['id'=>$ids])->update($data);
            if($result)  $this->success('修改成功');
            $this->success('修改失败');
        }
        $row = $this->model->find($ids)->toArray();
        $this->assign('row',$row);
        return  $this->fetch();
    }


    public function award($uid,$admin_id){
        //代理商赠送金额设置
       $info =  (new Register())->where(['admin_id'=>$admin_id,'is_del'=>0])->find();
       if($info){
           $register_award = $info['register_award'];
           if($register_award > 0){
               (new AccountLogic())->addAccount($uid,$admin_id,1,$register_award,'注册奖励','后台注册奖励');
           }
       }
    }

}
