<?php

namespace app\admin\controller\remittance;

use app\admin\model\Users;
use app\common\controller\Backend;
use datamodel\ConfigRegister;
use datamodel\HomePage;
use logicmodel\AccountLogic;
use logicmodel\award\Recommend;
use logicmodel\IntegralLogic;
use logicmodel\MemberLogic;
use think\Db;
use think\Exception;

/**
 * 汇款记录管理
 *
 * @icon fa fa-circle-o
 */
class Record extends Backend
{

    /**
     * Record模型对象
     * @var \app\admin\model\remittance\Record
     */
    protected $model = null;
    protected $dataLimit = 'auth';
    protected $dataLimitField = 'admin_id';
    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\remittance\Record;
        $this->view->assign("isPoolingList", $this->model->getIsPoolingList());
        $this->view->assign("statusList", $this->model->getStatusList());
        $this->view->assign("isCommissionList", $this->model->getIsCommissionList());
    }



    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */


    /**
     * 查看
     */
    public function index()
    {
        //当前是否为关联查询
        $this->relationSearch = true;
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();

            $list = $this->model
                    ->with(['admin','users','currency','radmin'])
                    ->where($where)
                    ->order($sort, $order)
                    ->paginate($limit);

            foreach ($list as $row) {
                $row->visible(['id','account','from_address','address','hash','is_pooling','create_time','status','is_commission','review_admin_id','operation_time']);
                $row->visible(['admin']);
				$row->getRelation('admin')->visible(['username']);
                $row->visible(['radmin']);
                $row->getRelation('radmin')->visible(['username']);
				$row->visible(['users']);
				$row->getRelation('users')->visible(['member']);
				$row->visible(['currency']);
				$row->getRelation('currency')->visible(['name']);
            }

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }

    /**
     * 充值通过
     * @param $ids
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function pass($ids){
        $info =  $this->model->alias('r')
            ->join('users u','u.id = r.uid')
            ->field(['r.*','u.member'])
            ->where(['r.id'=>$ids,'r.status'=>0])
            ->find();
        if(empty($info)) return json(['code'=>0,'msg'=>'充值信息错误']);
        Db::startTrans();
        //增加账户余额
        $uid = $info['uid'];
        $admin_id = $info['admin_id'];
        $account = $info['account'];
       $result = (new AccountLogic())->addAccount($uid,$admin_id,$info['currency_id'],$account,'充值','交易'.$info['hash'].'充值到账');
       if(!$result){
           Db::rollback();
           return json(['code'=>0,'msg'=>'操作失败']);
       }
        $result =  $this->model->where(['id'=>$ids,'status'=>0])->update(['status'=>1,'review_admin_id'=>$this->auth->id,'is_commission'=>1,'operation_time'=>date('Y-m-d H:i:s')]);
        if($result) {
            try {
                $usersData = new Users();
                $usersData->where(['id' => $uid])->setInc('remittance_money', $account);
                $usersData->where(['id' => $uid])->setInc('remittance_number', 1);
                $parentData = (new MemberLogic())->listParentArr($uid);
                $usersData->where(['id' => ['in', $parentData]])->setInc('group_remittance_money', $account);
                $this->checkAccount($uid, $admin_id);
                (new Recommend())->award([['uid' => $uid, 'admin_id' => $admin_id, 'account' => $account]]);
                (new IntegralLogic())->deductAccount($uid, $admin_id, $account, '会员充值', '会员' . $info['member'] . '充值,积分抵扣');
            }catch (Exception $exception){

            }
           Db::commit();
            return json(['code'=>1,'msg'=>'操作成功']);
        }
        Db::rollback();
        return json(['code'=>0,'msg'=>'操作失败']);
    }

    /**
     * 激活用户/更新平台数据
     * @param $uid
     * @param $admin_id
     * @return bool
     * @throws Exception
     */
    public function checkAccount($uid,$admin_id){
        $active_account =  (new ConfigRegister())->where(['is_del'=>0,'admin_id'=>$admin_id])->value('active_account');
        if(empty($active_account)) return false;
        $usersData = new \datamodel\Users();
        $result =  $usersData->where(['is_active'=>0,'id'=>$uid,'remittance_money'=>['>=',$active_account]])->update(['is_active'=>1]);
        if($result>0){
            $homePageData = new HomePage();
            $homePageData->where(['admin_id'=>$admin_id,'is_del'=>0])->setInc('member_count',1);
        }
    }
    /**
     * 充值拒绝
     * @param $ids
     * @return \think\response\Json
     */
    public function nopass($ids){
       $result =  $this->model->where(['id'=>$ids,'status'=>0])->update(['status'=>2,'review_admin_id'=>$this->auth->id]);
       if($result) return json(['code'=>1,'msg'=>'操作成功']);
        return json(['code'=>0,'msg'=>'操作失败']);
    }

}
