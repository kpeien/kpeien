<?php

namespace app\admin\controller\projects;

use app\common\controller\Backend;
use logicmodel\AccountLogic;
use think\Db;

/**
 * 
 *
 * @icon fa fa-circle-o
 */
class Record extends Backend
{

    /**
     * Record模型对象
     * @var \app\admin\model\projects\Record
     */
    protected $model = null;
    protected $dataLimit = 'auth';
    protected $dataLimitField = 'admin_id';
    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\projects\Record;
        $this->view->assign("statusList", $this->model->getStatusList());
    }



    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */


    /**
     * 查看
     */
    public function index()
    {
        //当前是否为关联查询
        $this->relationSearch = true;
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();

            $list = $this->model
                    ->with(['admin','users','project'])
                    ->where($where)
                    ->order($sort, $order)
                    ->paginate($limit);

            foreach ($list as $row) {
                $row->visible(['id','money','status','award_day','award_money','create_time']);
                $row->visible(['admin']);
				$row->getRelation('admin')->visible(['username']);
				$row->visible(['users']);
				$row->getRelation('users')->visible(['member']);
				$row->visible(['project']);
				$row->getRelation('project')->visible(['name','day','rate']);
            }

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }
    public function end($ids){
        $info = $this->model->find($ids);
        if(empty($info)) return json(['code'=>0,'msg'=>'投资记录信息错误']);
        if($info['status'] == 0) return json(['code'=>0,'msg'=>'当前投资已结束']);
        Db::startTrans();
        $result = $this->model->where(['id'=>$ids])->update(['status'=>0,'end_time'=>date('Y-m-d H:i:s')]);
        if($result) {
           $result =  (new AccountLogic())->addAccount($info['uid'],$info['admin_id'],2,$info['money'],'投资结束','后台结束会员投资');
           if($result){
               Db::commit();
               return  json(['code'=>1,'msg'=>'结束成功']);
           }

        }
        Db::rollback();
        return  json(['code'=>0,'msg'=>'结束失败']);
    }
}
