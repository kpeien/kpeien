<?php

namespace app\admin\controller\config;

use app\common\controller\Backend;
use logicmodel\WalletLogic;

/**
 * 
 *
 * @icon fa fa-circle-o
 */
class Finance extends Backend
{

    /**
     * Finance模型对象
     * @var \app\admin\model\config\Finance
     */
    protected $model = null;
    protected $dataLimit = 'auth';
    protected $dataLimitField = 'admin_id';
    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\config\Finance;
        $this->view->assign("typeList", $this->model->getTypeList());
        $this->view->assign("reviewTypeList", $this->model->getReviewTypeList());
    }



    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */


    /**
     * 查看
     */
    public function index()
    {
        //当前是否为关联查询
        $this->relationSearch = true;
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();

            $list = $this->model
                    ->with(['admin'])
                    ->where($where)
                    ->order($sort, $order)
                    ->paginate($limit);

            foreach ($list as $row) {
                $row->visible(['id','address','balance','min','type','max','review_type','fee_rate']);
                $row->visible(['admin']);
				$row->getRelation('admin')->visible(['username']);
            }

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }
    public function del($ids = "")
    {
        $result = $this->model->where(['id'=>['in',$ids]])->update(['is_del'=>1]);
        if($result) return json(['code'=>1,'msg'=>'删除成功']);
        return json(['code'=>1,'msg'=>'删除成功']);
    }

    /**
     * 更新钱包
     * @param string $ids
     * @return mixed|\think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function edit($ids=''){
        if(request()->isPost()){
            $data = input('post.');
            $data = $data['row'];
            $type = $this->model->where(['id'=>$ids])->value('type');
            if($type == 1){ //出款钱包
                if(!empty($data['address_key'])){
                    $address_key = $data['address_key'];
                    if(strlen($address_key) != 64) return json(['code'=>0,'msg'=>'私钥格式错误']);
                    $address = (new WalletLogic())->importPrivateKey($address_key);
                    if($address === false) return json(['code'=>0,'msg'=>'私钥格式错误']);
                    $data['address'] = $address;
                }
                unset($data['address_key']);
               $result =  $this->model->where(['id'=>$ids])->update($data);
              if($result)  return json(['code'=>1,'msg'=>'修改成功']);
                return json(['code'=>0,'msg'=>'修改失败']);
            }elseif($type == 2){ //收款钱包
                $address = $data['address'];
                if(!empty($data['address'])){
                    if(strlen($address) != 34) return json(['code'=>0,'msg'=>'收款钱包格式错误']);
                }
                $result =  $this->model->where(['id'=>$ids])->update($data);
                if($result)  return json(['code'=>1,'msg'=>'修改成功']);
                return json(['code'=>0,'msg'=>'修改失败']);
            }
            return json(['code'=>0,'msg'=>'钱包类型错误']);
        }

        $row = $this->model->find($ids);
        $this->assign('row',$row);
        $this->assign('ids',$ids);
        return $this->fetch();
    }
    public function query($ids){
       $address =  $this->model->where(['id'=>$ids])->value('address');
       if(empty($address)) return json(['code'=>0,'msg'=>'未绑定地址']);
       $balance =  (new WalletLogic())->getBalance($address);
       $this->model->where(['id'=>$ids])->update(['balance'=>$balance]);
       return json(['code'=>1,'msg'=>"查询成功"]);
    }
}
