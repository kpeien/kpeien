<?php

return [
    'Admin_id'                => '代理商账号',
    'Create_time'             => '时间',
    'Remittance_money'        => 'TRX充值金额',
    'Remittance_person_count' => '充值人数',
    'Remittance_number'       => '充值笔数',
    'Draw_money'              => 'TRX提现金额',
    'Draw_person_count'       => '提现人数',
    'Draw_number'             => '提现笔数',
    'Admin.username'          => '代理商账号'
];
