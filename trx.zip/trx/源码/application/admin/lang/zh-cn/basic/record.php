<?php

return [
    'Admin_id'       => '代理商ID',
    'Uid'            => '会员ID',
    'Account'        => '收益金额',
    'Rate'        => '佣金比例(%)',
    'Status'         => '接收状态',
    'Status 0'       => '未接收',
    'Status 1'       => '已接收',
    'Create_time'    => '收益时间',
    'Award_time'     => '领取时间',
    'Admin.username' => '代理商账号',
    'Users.member'   => '会员账号'
];
