<?php

return [
    'Admin_id'           => '代理商',
    'Accumulated_profit' => '累计利润金额',
    'Member_count'       => '会员资格人数',
    'Is_del'             => '删除状态',
    'Is_del 0'           => '未删除',
    'Is_del 1'           => '已删除',
    'Admin.username'     => '代理商账号'
];
