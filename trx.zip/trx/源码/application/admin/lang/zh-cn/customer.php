<?php

return [
    'Admin_id'       => '代理商名称',
    'Service_url'    => '客服连接',
    'Is_show'        => '展示状态',
    'Is_show 0'      => '隐藏',
    'Is_show 1'      => '展示',
    'Is_del'         => '删除状态',
    'Is_del 0'       => '未删除',
    'Is_del 1'       => '已删除',
    'Admin.username' => '代理商账号'
];
