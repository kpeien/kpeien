<?php

return [
    'Image'    => '图片',
    'Order'    => '排序值',
    'Is_del'   => '删除状态',
    'Is_del 0' => '未删除',
    'Is_del 1' => '已删除'
];
