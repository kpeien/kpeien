<?php

return [
    'Admin_id'       => '代理商账号',
    'Image'          => '图片',
    'Name'           => '项目名称',
    'Min'            => '最小投资',
    'Max'            => '最大投资',
    'Day'            => '周期',
    'Rate'           => '日收益比例',
    'Limit_number'   => '单人限购次数',
    'Sales'          => '已购次数',
    'Order'          => '排序值',
    'Status'         => '状态',
    'Status 0'       => '已下架',
    'Status 1'       => '上架',
    'Create_time'    => '创建时间',
    'Is_del'         => '删除状态',
    'Is_del 0'       => '未删除',
    'Is_del 1'       => '已删除',
    'Admin.username' => '代理商账号'
];
