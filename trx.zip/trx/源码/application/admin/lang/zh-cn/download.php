<?php

return [
    'Admin_id'       => '代理商账号',
    'Download_url'   => '代理商下载地址',
    'Version'        => '版本',
    'Type'           => '平台类型',
    'Type 1'         => 'android',
    'Type 2'         => 'ios',
    'Is_del'         => '删除状态',
    'Is_del 0'       => '未删除',
    'Is_del 1'       => '已删除',
    'Admin.username' => '代理商账号'
];
