<?php

return [
    'Name'      => '语言名称',
    'Is_show'   => '是否展示',
    'Is_show 0' => '隐藏',
    'Is_show 1' => '展示',
    'Order'     => '排序值',
    'Is_del'    => '删除装填',
    'Is_del 0'  => '未删除',
    'Is_del 1'  => '已删除'
];
