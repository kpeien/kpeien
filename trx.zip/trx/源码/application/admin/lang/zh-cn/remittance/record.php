<?php

return [
    'Uid'             => '用户ID',
    'Admin_id'        => '所属代理商',
    'Currency_id'     => '币种ID',
    'Account'         => '充值金额（TRX）',
    'From_address'    => '转账地址',
    'Address'         => '充值地址',
    'Hash'            => '交易HASH',
    'Is_pooling'      => '是否归集',
    'Is_pooling 0'    => '未归集',
    'Is_pooling 1'    => '已归集',
    'Create_time'     => '充值时间',
    'Operation_time'  =>'操作时间',
    'Status'          => '状态',
    'Status 0'        => '待审核',
    'Status 1'        => '成功',
    'Status 2'        => '失败',
    'Fee_account'     => '矿工费',
    'Is_commission'   => '是否已分佣',
    'Is_commission 0' => '待审核',
    'Is_commission 1' => '未分佣',
    'Is_commission 2' => '已分佣',
    'Admin.username'  => '代理商账号',
    'Radmin.username'  => '操作代理商账号',
    'Users.member'    => '会员账号',
    'Currency.name'   => '账户名称'
];
