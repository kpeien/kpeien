<?php

return [
    'Admin_id'       => '代理',
    'Address'        => '钱包地址',
    'Balance'        => '账户余额',
    'Address_key'    => '钱包私钥',
    'Min'            => '最小金额',
    'Max'            => '最大金额',
    'Type'           => '账户类型',
    'Type 1'         => '出款',
    'Type 2'         => '收款',
    'Review_type'    => '审核类型',
    'Review_type 1'  => '自动审核',
    'Review_type 2'  => '手动审核',
    'Admin.username' => '代理商账号',
    'Fee_rate'=>'提现手续费'
];
