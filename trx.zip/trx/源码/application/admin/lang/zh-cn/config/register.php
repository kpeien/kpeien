<?php

return [
    'Admin_id'       => '代理商账号',
    'Register_award' => '注册奖励',
    'Active_account' => '充值TRX激活金额',
    'Level1'         => '一级奖励',
    'Level2'         => '二级奖励',
    'Level3'         => '三级奖励',
    'Is_auth'        => '是否开启登录验证码',
    'Is_auth 0'      => '不开启',
    'Is_auth 1'      => '开启',
    'Is_del'         => '删除状态',
    'Is_del 0'       => '未删除',
    'Is_del 1'       => '已删除',
    'Admin.username' => '代理商账号',
];
