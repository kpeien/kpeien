<?php

return [
    'Uid'             => '会员ID',
    'Admin_id'        => '代理商',
    'Review_admin_id' => '审核人',
    'Currency_id'     => '提现币种',
    'Order_num'       => '提币订单号',
    'Account'         => '提币金额',
    'Reality_account' => '到账金额',
    'Address'         => '提现地址',
    'Hash'            => '交易HASH',
    'Status'          => '审核状态',
    'Status 0'        => '未审核',
    'Status 1'        => '已通过',
    'Status 2'        => '已拒绝',
    'Refuse'          => '审核备注',
    'Create_time'     => '申请时间',
    'Operation_time'  =>'操作时间',
    'Admin.username'  => '代理商账号',
    'Radmin.username'  => '操作代理商账号',
    'Users.member'    => '会员账号',
    'Currency.name'   => '账户名称'
];
