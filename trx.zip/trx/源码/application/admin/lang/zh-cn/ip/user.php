<?php

return [
    'Admin_id'       => '代理商账号',
    'Uid'            => '会员账号',
    'Ip'             => 'IP地址',
    'Create_time'    => '记录时间',
    'Admin.username' => '代理名',
    'Users.member'   => '会员账号'
];
