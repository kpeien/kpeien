<?php

return [
    'Admin_id'       => '代理商账号',
    'Uid'            => '会员ID',
    'Project_id'     => '项目名称',
    'Money'          => '投资金额',
    'Status'         => '收益状态',
    'Status 0'       => '已结束',
    'Status 1'       => '收益中',
    'Award_day'      => '已收益天数',
    'Award_money'    => '已收益金额',
    'Create_time'    => '购买时间',
    'Award_time'     => '每日奖励发放时间',
    'End_time'       => '收益结束时间',
    'Admin.username' => '代理商账号',
    'Users.member'   => '会员账号',
    'Project.name'   => '项目名称',
    'Project.day'    => '周期',
    'Project.rate'   => '日收益比例'
];
