<?php

return [
    'Admin_id'       => '代理商账号',
    'Domain_name'    => '域名',
    'Is_del'         => '删除状态',
    'Is_del 0'       => '未删除',
    'Is_del 1'       => '已删除',
    'Admin.username' => '代理商账号'
];
