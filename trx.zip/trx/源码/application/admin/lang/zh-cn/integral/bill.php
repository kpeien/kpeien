<?php

return [
    'Uid'            => '会员ID',
    'Admin_id'       => '所属代理',
    'Account'        => '变动金额',
    'Before_account' => '变动前金额',
    'After_account'  => '变动后金额',
    'Bill_type'      => '账单类型',
    'Remark'         => '备注',
    'Type'           => '收支类型',
    'Type 1'         => '收入',
    'Type 2'         => '支出',
    'Create_time'    => '记录时间',
    'Admin.username' => '代理商名',
    'Users.member'   => '会员账号'
];
