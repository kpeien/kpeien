<?php

return [
    'Admin_id'         => '代理商ID',
    'Account'          => '充值TRX数量',
    'Integral_account' => '充值积分数量',
    'From_address'     => '转账地址',
    'Address'          => '充值地址',
    'Hash'             => '交易hash',
    'Is_pooling'       => '是否归集',
    'Is_pooling 0'     => '未归集',
    'Is_pooling 1'     => '已归集',
    'Create_time'      => '添加时间',
    'Is_del'           => '0=不删除,1=删除',
    'Admin.username'   => '代理商账号'
];
