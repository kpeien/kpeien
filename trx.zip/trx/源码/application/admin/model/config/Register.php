<?php

namespace app\admin\model\config;

use think\Model;


class Register extends Model
{

    

    

    // 表名
    protected $name = 'config_register';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'is_auth_text'
    ];
    

    
    public function getIsAuthList()
    {
        return ['0' => __('Is_auth 0'), '1' => __('Is_auth 1')];
    }


    public function getIsAuthTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['is_auth']) ? $data['is_auth'] : '');
        $list = $this->getIsAuthList();
        return isset($list[$value]) ? $list[$value] : '';
    }




    public function admin()
    {
        return $this->belongsTo('app\admin\model\Admin', 'admin_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }
}
