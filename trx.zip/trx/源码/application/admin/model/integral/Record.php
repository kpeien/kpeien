<?php

namespace app\admin\model\integral;

use think\Model;


class Record extends Model
{

    

    

    // 表名
    protected $name = 'integral_record';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'is_pooling_text'
    ];
    

    
    public function getIsPoolingList()
    {
        return ['0' => __('Is_pooling 0'), '1' => __('Is_pooling 1')];
    }


    public function getIsPoolingTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['is_pooling']) ? $data['is_pooling'] : '');
        $list = $this->getIsPoolingList();
        return isset($list[$value]) ? $list[$value] : '';
    }




    public function admin()
    {
        return $this->belongsTo('app\admin\model\Admin', 'admin_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }
}
