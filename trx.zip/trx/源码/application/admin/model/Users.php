<?php

namespace app\admin\model;

use think\Model;


class Users extends Model
{

    

    

    // 表名
    protected $name = 'users';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'status_text',
        'is_active_text',
        'is_draw_text'
    ];
    

    
    public function getStatusList()
    {
        return ['0' => __('Status 0'), '1' => __('Status 1')];
    }

    public function getIsActiveList()
    {
        return ['0' => __('Is_active 0'), '1' => __('Is_active 1')];
    }

    public function getIsDrawList()
    {
        return ['0' => __('Is_draw 0'), '1' => __('Is_draw 1')];
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getIsActiveTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['is_active']) ? $data['is_active'] : '');
        $list = $this->getIsActiveList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getIsDrawTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['is_draw']) ? $data['is_draw'] : '');
        $list = $this->getIsDrawList();
        return isset($list[$value]) ? $list[$value] : '';
    }




    public function admin()
    {
        return $this->belongsTo('Admin', 'admin_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }
}
