<?php

namespace app\admin\model\ip;

use think\Model;


class Users extends Model
{

    

    

    // 表名
    protected $name = 'ip_users';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    







    public function admin()
    {
        return $this->belongsTo('app\admin\model\Admin', 'admin_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }


    public function userss()
    {
        return $this->belongsTo('app\admin\model\Users', 'uid', 'id', [], 'LEFT')->setEagerlyType(0);
    }
}
